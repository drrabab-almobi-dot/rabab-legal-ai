---
name: Domain & Payment URLs
description: الدومين الرسمي للمنصة وروابط بوابة الدفع
---

## الدومين الرسمي
`rabablegal.com`

## روابط Moyasar المسجلة
- Website URL: `https://rabablegal.com`
- Callback URL: `https://rabablegal.com/payment/callback`

**Why:** الدومين مُحجوز وسيُربط بعد النشر على Replit Deployment.

**How to apply:** أي إعداد يحتاج رابط المنصة (OG tags، Moyasar، emails، webhooks) يستخدم `https://rabablegal.com`.

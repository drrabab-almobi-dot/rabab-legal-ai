RABAB LEGAL AI — COMPLETE SOURCE ARCHIVE
============================================

This archive contains the runnable project source and recovery-critical configuration:
- web frontend, API server, shared libraries, scripts, and mobile artifact source
- package manifests and lockfile
- Replit, Vercel, artifact, and project configuration
- database migration history
- GitHub CI and Claude workflow definitions
- project documentation and agent memory where tracked

Intentionally excluded:
- node_modules, build output, caches, and local runtime state
- .env files, credentials, and secrets
- database dumps and split database backup parts
- large historical exports, screenshots, and unused attached assets

Restore:
1. Extract this archive into an empty workspace.
2. Set the required environment secrets through the secure secrets manager.
3. Run pnpm install --frozen-lockfile.
4. Run the project typecheck/build commands from package.json.
5. Apply database migrations against the intended Supabase environment.

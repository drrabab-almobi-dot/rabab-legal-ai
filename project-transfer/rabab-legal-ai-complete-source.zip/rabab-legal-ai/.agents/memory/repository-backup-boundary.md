---
name: Repository backup boundary
description: Boundary between runnable source kept in GitHub and sensitive or oversized local exports
---

Keep the runnable application source, configuration templates, workflow definitions, and database migration history in GitHub. Do not upload database dumps, split dump parts, full-project archives, or other exports that may contain user data or secrets.

**Why:** The local transfer audit found that the remaining files were mostly multi-gigabyte exports and database backups, not runtime source. Uploading them would create size, privacy, and accidental-restore risks without improving the application's ability to run.

**How to apply:** When comparing a local workspace with GitHub, verify all runtime paths and migrations first. Preserve large or sensitive material through a secured backup channel, not as ordinary repository files; store only a small source-transfer archive when a temporary handoff is needed.